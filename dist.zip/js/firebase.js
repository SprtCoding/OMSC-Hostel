const firebaseConfig = {
    apiKey: "AIzaSyD0ZQYT-ZKji8Y02nlc8L6nqs4-78uwL4E",
    authDomain: "omsc-hostel-booking.firebaseapp.com",
    projectId: "omsc-hostel-booking",
    databaseURL: "https://omsc-hostel-booking-default-rtdb.firebaseio.com/",
    storageBucket: "omsc-hostel-booking.appspot.com",
    messagingSenderId: "168692280364",
    appId: "1:168692280364:web:652e83332e72f0e8c9f589",
    measurementId: "G-68ZDM27DX6"
};
firebase.initializeApp(firebaseConfig);